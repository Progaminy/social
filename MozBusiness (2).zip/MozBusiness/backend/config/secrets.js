module.exports = {
    secretKey: process.env.SECRET_KEY,
    brevoApiKey: process.env.BREVO_API_KEY,
    mozPaymentUrl: process.env.MOZ_PAYMENT_URL,
    paypalClientId: process.env.PAYPAL_CLIENT_ID,
  };
  