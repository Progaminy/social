const Product = require('../models/Product');

// Função para criar produto
exports.createProduct = async (req, res) => {
  console.log('Request body:', req.body);
  console.log('Request files:', req.files);

  const { name, price, installmentAccepted, location, contactNumber, category } = req.body;

  let images = [];
  if (req.files) {
    images = req.files.map(file => file.path.replace(/\\/g, "/"));
  }

  try {
    const newProduct = new Product({
      name,
      price,
      installmentAccepted,
      location,
      contactNumber,
      category,
      images,
      userId: req.user.id,
    });
    await newProduct.save();
    res.status(201).json({ message: 'Produto criado com sucesso', product: newProduct });
  } catch (error) {
    console.error('Erro ao criar produto:', error);
    res.status(500).json({ message: 'Erro ao criar produto', error: error.message });
  }
};

// Função para adicionar um like
exports.likeProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.productId);
    if (product.dislikes.includes(req.user.id)) {
      product.dislikes = product.dislikes.filter(userId => userId.toString() !== req.user.id.toString());
    }

    if (!product.likes.includes(req.user.id)) {
      product.likes.push(req.user.id);
      await product.save();
      res.status(200).json({ message: 'Produto curtido com sucesso', likes: product.likes.length, dislikes: product.dislikes.length });
    } else {
      res.status(400).json({ message: 'Você já curtiu este produto' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Erro ao curtir produto', error: error.message });
  }
};

// Função para adicionar um dislike
exports.dislikeProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.productId);
    if (product.likes.includes(req.user.id)) {
      product.likes = product.likes.filter(userId => userId.toString() !== req.user.id.toString());
    }

    if (!product.dislikes.includes(req.user.id)) {
      product.dislikes.push(req.user.id);
      await product.save();
      res.status(200).json({ message: 'Produto não curtido com sucesso', likes: product.likes.length, dislikes: product.dislikes.length });
    } else {
      res.status(400).json({ message: 'Você já não curtiu este produto' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Erro ao não curtir produto', error: error.message });
  }
};

// Função para adicionar um comentário
exports.commentProduct = async (req, res) => {
  const { comment } = req.body;
  const wordCount = comment.split(' ').length;

  if (wordCount > 20) {
    return res.status(400).json({ message: 'O comentário não pode ter mais de 20 palavras.' });
  }

  try {
    const product = await Product.findById(req.params.productId);
    if (!product) {
      return res.status(404).json({ message: 'Produto não encontrado' });
    }

    const newComment = {
      userId: req.user.id,
      comment,
      date: new Date()
    };
    product.comments.push(newComment);
    await product.save();
    res.status(200).json({ message: 'Comentário adicionado com sucesso', comments: product.comments });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao adicionar comentário', error: error.message });
  }
};

// Função para listar produtos por categoria
exports.getProductsByCategory = async (req, res) => {
  try {
    const products = await Product.find({ category: req.params.category }).populate('userId', 'fullName profilePicture').sort({ createdAt: -1 });
    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao obter produtos', error: error.message });
  }
};

// Função para listar produtos de um usuário
exports.getUserProducts = async (req, res) => {
  try {
    const products = await Product.find({ userId: req.user.id }).populate('userId', 'fullName profilePicture').sort({ createdAt: -1 });
    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao obter produtos do usuário', error: error.message });
  }
};

// Função para editar produto
exports.editProduct = async (req, res) => {
  const { productId, updates } = req.body;

  try {
    const product = await Product.findByIdAndUpdate(productId, updates, { new: true });
    res.status(200).json({ message: 'Produto atualizado com sucesso', product });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao atualizar produto', error: error.message });
  }
};

// Função para apagar produto
exports.deleteProduct = async (req, res) => {
  const { productId } = req.params;

  try {
    await Product.findByIdAndDelete(productId);
    res.status(200).json({ message: 'Produto apagado com sucesso' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao apagar produto', error: error.message });
  }
};

// Função para marcar produto como vendido
exports.markAsSold = async (req, res) => {
  const { productId } = req.params;

  try {
    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ message: 'Produto não encontrado' });
    }
    if (product.userId.toString() !== req.user.id.toString()) {
      return res.status(403).json({ message: 'Apenas o proprietário pode marcar o produto como vendido' });
    }
    product.sold = true;
    await product.save();

    setTimeout(async () => {
      await Product.findByIdAndDelete(productId);
    }, 48 * 60 * 60 * 1000); // 48 horas

    res.status(200).json({ message: 'Produto marcado como vendido' });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao marcar produto como vendido', error: error.message });
  }
};

// Função para obter comentários de um produto com paginação
exports.getComments = async (req, res) => {
  try {
    const product = await Product.findById(req.params.productId).populate('comments.userId', 'fullName profilePicture');
    if (!product) {
      return res.status(404).json({ message: 'Produto não encontrado' });
    }
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;

    const comments = product.comments.slice(startIndex, endIndex);
    res.status(200).json({ comments, totalComments: product.comments.length, page, limit });
  } catch (error) {
    res.status(500).json({ message: 'Erro ao obter comentários', error: error.message });
  }
};

// Função para buscar produtos
exports.searchProducts = async (req, res) => {
  try {
    const { query } = req.query;
    const regex = new RegExp(query, 'i');
    const products = await Product.find({
      $or: [
        { name: regex },
        { contactNumber: regex },
        { _id: regex },
        { category: regex },
        { description: regex },
        { 'userId.fullName': regex }
      ]
    }).populate('userId', 'fullName profilePicture');

    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar produtos', error: error.message });
  }
};
