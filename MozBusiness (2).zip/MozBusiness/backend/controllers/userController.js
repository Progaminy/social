const User = require('../models/User');
const bcrypt = require('bcryptjs');
const path = require('path');

exports.updateProfilePicture = async (req, res) => {
  console.log('Update profile picture request received');
  
  if (req.fileValidationError) {
    console.log('File validation error:', req.fileValidationError);
    return res.status(400).json({ message: req.fileValidationError });
  }

  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      console.log('User not found');
      return res.status(404).json({ message: 'Usuário não encontrado' });
    }

    console.log('File uploaded:', req.file);

    // Normalizando o caminho para o formato Unix
    const normalizedPath = req.file.path.replace(/\\/g, "/");
    user.profilePicture = normalizedPath;

    await user.save();
    console.log('Profile picture path saved:', normalizedPath);

    // Retorne o caminho relativo da imagem
    res.status(200).json({ message: 'Foto de perfil atualizada com sucesso', profilePicture: `/uploads/${req.file.filename}` });
  } catch (err) {
    console.error('Erro ao atualizar perfil:', err);
    res.status(500).json({ message: 'Erro ao atualizar foto de perfil', error: err.message });
  }
};

// Outras funções do controlador de usuário...

exports.changePassword = async (req, res) => {
  const { oldPassword, newPassword, confirmPassword } = req.body;

  if (newPassword !== confirmPassword) {
    return res.status(400).json({ message: 'As senhas não coincidem' });
  }

  try {
    const user = await User.findById(req.user.id);
    const isMatch = await bcrypt.compare(oldPassword, user.password);

    if (!isMatch) {
      return res.status(400).json({ message: 'Senha antiga incorreta' });
    }

    user.password = await bcrypt.hash(newPassword, 8);
    await user.save();
    res.status(200).json({ message: 'Senha alterada com sucesso' });
  } catch (err) {
    console.error('Erro ao alterar senha:', err);
    res.status(500).json({ message: 'Erro ao alterar senha', error: err.message });
  }
};

exports.getUserData = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    res.status(200).json({ user });
  } catch (err) {
    console.error('Erro ao obter dados do usuário:', err);
    res.status(500).json({ message: 'Erro ao obter dados do usuário', error: err.message });
  }
};
