const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');
const authMiddleware = require('../middlewares/authMiddleware');
const multer = require('multer');
const path = require('path');

// Configuração do multer para upload de arquivos
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, '..', 'uploads'));
  },
  filename: function (req, file, cb) {
    cb(null, `${req.user.id}-${Date.now()}${path.extname(file.originalname)}`);
  },
});

const upload = multer({ storage: storage });

router.post('/create', authMiddleware, upload.array('images', 10), productController.createProduct);
router.put('/edit', authMiddleware, upload.array('images', 10), productController.editProduct);
router.delete('/delete/:productId', authMiddleware, productController.deleteProduct);
router.put('/mark-as-sold/:productId', authMiddleware, productController.markAsSold);
router.post('/like/:productId', authMiddleware, productController.likeProduct);
router.post('/dislike/:productId', authMiddleware, productController.dislikeProduct);
router.post('/comment/:productId', authMiddleware, productController.commentProduct);
router.get('/comments/:productId', authMiddleware, productController.getComments);
router.get('/category/:category', productController.getProductsByCategory);
router.get('/search', authMiddleware, productController.searchProducts); // Adicione esta rota

module.exports = router;
