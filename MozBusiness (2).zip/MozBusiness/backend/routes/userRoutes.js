const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authMiddleware = require('../middlewares/authMiddleware');
const upload = require('../middlewares/uploadMiddleware');

router.put('/profile-picture', authMiddleware, upload.single('profilePicture'), userController.updateProfilePicture);
router.put('/change-password', authMiddleware, userController.changePassword);
router.get('/data', authMiddleware, userController.getUserData);

module.exports = router;
