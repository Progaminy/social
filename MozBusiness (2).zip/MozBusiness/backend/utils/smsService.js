const axios = require('axios');
const secrets = require('../config/secrets');

const sendSms = async (phoneNumber, message) => {
  try {
    const response = await axios.post('https://api.brevo.com/v3/smtp/email', {
      sender: { email: 'noreply@mozbusiness.com', name: 'MozBusiness' },
      to: [{ email: phoneNumber + '@sms.brevo.com' }],
      subject: 'Recuperação de Senha',
      textContent: message,
    }, {
      headers: {
        'api-key': secrets.brevoApiKey,
      },
    });

    return response.data;
  } catch (error) {
    throw new Error('Erro ao enviar SMS: ' + error.message);
  }
};

module.exports = sendSms;
