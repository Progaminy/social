document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const countryPrefix = document.getElementById('countryPrefix').value;
  const phoneNumber = document.getElementById('phoneNumber').value;
  const fullPhoneNumber = `${countryPrefix}${phoneNumber}`;
  const password = document.getElementById('password').value;

  const response = await fetch('/api/auth/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ phoneNumber: fullPhoneNumber, password }),
  });

  const data = await response.json();

  if (response.ok) {
    alert(data.message);
    localStorage.setItem('token', data.token);
    window.location.href = '/main';
  } else {
    alert(data.message);
  }
});
