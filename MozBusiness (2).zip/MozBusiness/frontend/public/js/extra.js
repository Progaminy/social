document.getElementById('profilePictureForm').addEventListener('submit', async (e) => {
    e.preventDefault();
  
    const formData = new FormData();
    formData.append('profilePicture', document.getElementById('profilePicture').files[0]);
  
    const token = localStorage.getItem('token');
  
    try {
      const response = await fetch('/api/users/profile-picture', {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });
  
      const data = await response.json();
  
      if (response.ok) {
        alert(data.message);
        window.location.href = '/main'; // Redirecionar para a página principal
        const profileImg = document.getElementById('profile-img');
        profileImg.src = `${data.profilePicture}?${new Date().getTime()}`; // Força a atualização da imagem
      } else {
        document.getElementById('error-message').textContent = data.message; // Exibir mensagem de erro específica
      }
    } catch (err) {
      console.error('Error during profile picture update:', err);
      document.getElementById('error-message').textContent = 'Erro ao atualizar foto de perfil. Por favor, tente novamente.';
    }
  });
  