document.getElementById('profilePictureForm').addEventListener('submit', async (e) => {
    e.preventDefault();
  
    const formData = new FormData();
    formData.append('profilePicture', document.getElementById('profilePicture').files[0]);
  
    const token = localStorage.getItem('token');
  
    try {
      const response = await fetch('/api/users/profile-picture', {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });
  
      const data = await response.json();
      console.log('Response from API:', data);
  
      if (response.ok) {
        alert(data.message);
        // Atualize a imagem do perfil no frontend
        const profileImg = document.getElementById('profile-img');
        profileImg.src = `${data.profilePicture}?${new Date().getTime()}`; // Força a atualização da imagem
      } else {
        document.getElementById('error-message').textContent = data.message;
      }
    } catch (err) {
      console.error('Error during profile picture update:', err);
      document.getElementById('error-message').textContent = 'Erro ao atualizar foto de perfil. Por favor, tente novamente.';
    }
  });
  