document.addEventListener('DOMContentLoaded', async () => {
  const token = localStorage.getItem('token');

  if (!token) {
    window.location.href = '/login';
  }

  const response = await fetch('/api/users/data', {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  const data = await response.json();

  if (response.ok) {  
    localStorage.setItem('userId', data.user._id);
    document.getElementById('user-name').textContent = data.user.fullName;
    const profilePicture = localStorage.getItem('profilePicture');
    if (profilePicture) {
      document.getElementById('profile-picture').src = `${profilePicture}?${new Date().getTime()}`;
    } else if (data.user.profilePicture) {
      document.getElementById('profile-picture').src = `/${data.user.profilePicture}`;
    }
  } else {
    displayError(data.message);
  }

  document.getElementById('logout').addEventListener('click', () => {
    localStorage.removeItem('token');
    localStorage.removeItem('profilePicture');
    window.location.href = '/login';
  });

  document.getElementById('searchForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const query = document.getElementById('searchInput').value;
    try {
      const response = await fetch(`/api/products/search?query=${query}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const products = await response.json();
      if (response.ok) {
        displayProducts(products);
      } else {
        displayError(products.message);
      }
    } catch (error) {
      handleError(error);
    }
  });

  document.querySelectorAll('.category').forEach(category => {
    category.addEventListener('click', async () => {
      const categoryName = category.getAttribute('data-category');
      try {
        const response = await fetch(`/api/products/category/${categoryName}`);
        const products = await response.json();
        displayProducts(products);
      } catch (error) {
        handleError(error);
      }
    });
  });

  async function displayProducts(products) {
    const productList = document.getElementById('productList');
    productList.innerHTML = '';

    products.forEach(product => {
      const productDiv = document.createElement('div');
      productDiv.className = 'product';

      if (product.images && product.images.length > 0) {
        product.images.forEach(image => {
          const productImage = document.createElement('img');
          productImage.src = `/${image}`;
          productImage.className = 'product-image';
          productImage.addEventListener('click', () => {
            openModal(productImage.src);
          });
          productDiv.appendChild(productImage);
        });
      }

      const productName = document.createElement('h3');
      productName.textContent = product.name;
      productDiv.appendChild(productName);

      const productId = document.createElement('p');
      productId.textContent = `ID do Produto: ${product._id}`;
      productDiv.appendChild(productId);

      const productPrice = document.createElement('p');
      productPrice.textContent = `Preço: ${product.price} MZN`;
      productDiv.appendChild(productPrice);

      if (product.installmentAccepted) {
        const installment = document.createElement('p');
        installment.textContent = 'Aceita Prestação';
        productDiv.appendChild(installment);
      }

      const contactNumber = document.createElement('p');
      contactNumber.textContent = `Contato: ${product.contactNumber}`;
      productDiv.appendChild(contactNumber);

      const supportNumber = document.createElement('p');
      supportNumber.textContent = 'Suporte: +258872599084';
      productDiv.appendChild(supportNumber);

      const intermediaryContact = document.createElement('p');
      intermediaryContact.textContent = `Contato Intermediário: ${product.intermediaryContact}`;
      productDiv.appendChild(intermediaryContact);

      const likeButton = document.createElement('button');
      likeButton.textContent = `Curtir (${product.likes.length})`;
      likeButton.className = 'like-button';
      likeButton.style.backgroundColor = product.likes.includes(localStorage.getItem('userId')) ? 'green' : '';
      likeButton.addEventListener('click', async () => {
        try {
          const response = await fetch(`/api/products/like/${product._id}`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          });
          const data = await response.json();
          if (response.ok) {
            likeButton.textContent = `Curtir (${data.likes})`;
            likeButton.style.backgroundColor = 'green';
            dislikeButton.style.backgroundColor = '';
          } else {
            displayError(data.message);
          }
        } catch (error) {
          handleError(error);
        }
      });
      productDiv.appendChild(likeButton);

      const dislikeButton = document.createElement('button');
      dislikeButton.textContent = `Não Curtir (${product.dislikes.length})`;
      dislikeButton.className = 'dislike-button';
      dislikeButton.style.backgroundColor = product.dislikes.includes(localStorage.getItem('userId')) ? 'red' : '';
      dislikeButton.addEventListener('click', async () => {
        try {
          const response = await fetch(`/api/products/dislike/${product._id}`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          });
          const data = await response.json();
          if (response.ok) {
            dislikeButton.textContent = `Não Curtir (${data.dislikes})`;
            dislikeButton.style.backgroundColor = 'red';
            likeButton.style.backgroundColor = '';
          } else {
            displayError(data.message);
          }
        } catch (error) {
          handleError(error);
        }
      });
      productDiv.appendChild(dislikeButton);

      if (product.userId._id === localStorage.getItem('userId')) {
        const soldCheckbox = document.createElement('input');
        soldCheckbox.type = 'checkbox';
        soldCheckbox.checked = product.sold;
        soldCheckbox.addEventListener('change', async () => {
          if (soldCheckbox.checked) {
            try {
              const response = await fetch(`/api/products/mark-as-sold/${product._id}`, {
                method: 'PUT',
                headers: {
                  'Authorization': `Bearer ${token}`,
                },
              });
              const data = await response.json();
              if (response.ok) {
                productDiv.classList.add('sold');
                setTimeout(() => {
                  productDiv.remove();
                }, 48 * 60 * 60 * 1000); // Remover após 48 horas
              } else {
                displayError(data.message);
                soldCheckbox.checked = false;
              }
            } catch (error) {
              handleError(error);
              soldCheckbox.checked = false;
            }
          }
        });
        productDiv.appendChild(soldCheckbox);
      }

      const commentForm = document.createElement('form');
      commentForm.innerHTML = `
        <input type="text" name="comment" placeholder="Adicionar comentário" maxlength="20">
        <button type="submit">Comentar</button>
      `;
      commentForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const commentInput = commentForm.querySelector('input[name="comment"]');
        const comment = commentInput.value;
        try {
          const response = await fetch(`/api/products/comment/${product._id}`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ comment }),
          });
          const data = await response.json();
          if (response.ok) {
            commentInput.value = ''; // Limpar campo de escrita após enviar comentário
            loadComments(product._id, productDiv); // Carregar os comentários após adicionar
          } else {
            displayError(data.message);
          }
        } catch (error) {
          handleError(error);
        }
      });
      productDiv.appendChild(commentForm);

      const commentsDiv = document.createElement('div');
      commentsDiv.className = 'comments';
      productDiv.appendChild(commentsDiv);

      loadComments(product._id, productDiv); // Carregar comentários ao exibir o produto

      productList.appendChild(productDiv);
    });
  }

  async function loadComments(productId, productDiv, page = 1, limit = 10) {
    try {
      const response = await fetch(`/api/products/comments/${productId}?limit=${limit}&page=${page}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const { comments, totalComments } = await response.json();
      const commentsDiv = productDiv.querySelector('.comments');
      commentsDiv.innerHTML = `<h4>Comentários (${totalComments}):</h4>`;

      comments.forEach(comment => {
        const commentDiv = document.createElement('div');
        commentDiv.className = 'comment';

        const commenterName = document.createElement('span');
        commenterName.className = 'commenter-name';
        commenterName.textContent = `${comment.userId.fullName}:`;

        const commenterImage = document.createElement('img');
        commenterImage.src = `/${comment.userId.profilePicture}`;
        commenterImage.className = 'commenter-image';

        const commentText = document.createElement('p');
        commentText.textContent = comment.comment;

        const commentDate = document.createElement('span');
        commentDate.className = 'comment-date';
        commentDate.textContent = new Date(comment.date).toLocaleString();

        commentDiv.appendChild(commenterImage);
        commentDiv.appendChild(commenterName);
        commentDiv.appendChild(commentText);
        commentDiv.appendChild(commentDate);
        commentsDiv.appendChild(commentDiv);
      });

      const paginationDiv = document.createElement('div');
      paginationDiv.className = 'pagination';
      commentsDiv.appendChild(paginationDiv);

      if (totalComments > page * limit) {
        const seeMoreButton = document.createElement('button');
        seeMoreButton.textContent = 'Ver mais';
        seeMoreButton.addEventListener('click', () => {
          loadComments(productId, productDiv, page + 1, limit);
        });
        paginationDiv.appendChild(seeMoreButton);
      }

      if (page > 1) {
        const seeLessButton = document.createElement('button');
        seeLessButton.textContent = 'Ver menos';
        seeLessButton.addEventListener('click', () => {
          commentsDiv.innerHTML = '';
          loadComments(productId, productDiv, 1, limit);
        });
        paginationDiv.appendChild(seeLessButton);
      }

    } catch (error) {
      handleError(error);
    }
  }

  function handleError(error) {
    console.error('Ocorreu um erro:', error);
    const errorDiv = document.createElement('div');
    errorDiv.style.position = 'fixed';
    errorDiv.style.top = '10px';
    errorDiv.style.right = '10px';
    errorDiv.style.backgroundColor = '#f8d7da';
    errorDiv.style.color = '#721c24';
    errorDiv.style.padding = '10px';
    errorDiv.style.border = '1px solid #f5c6cb';
    errorDiv.style.borderRadius = '5px';
    errorDiv.style.zIndex = '1000';
    errorDiv.textContent = `Erro: ${error.message}`;
    document.body.appendChild(errorDiv);

    setTimeout(() => {
      errorDiv.remove();
    }, 5000);
  }

  function displayError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.style.position = 'fixed';
    errorDiv.style.top = '10px';
    errorDiv.style.right = '10px';
    errorDiv.style.backgroundColor = '#f8d7da';
    errorDiv.style.color = '#721c24';
    errorDiv.style.padding = '10px';
    errorDiv.style.border = '1px solid #f5c6cb';
    errorDiv.style.borderRadius = '5px';
    errorDiv.style.zIndex = '1000';
    errorDiv.textContent = `Erro: ${message}`;
    document.body.appendChild(errorDiv);

    setTimeout(() => {
      errorDiv.remove();
    }, 5000);
  }

  function openModal(src) {
    const modal = document.getElementById('modal');
    const modalImage = document.getElementById('modalImage');
    modal.style.display = 'flex';
    modalImage.src = src;
  }

  function closeModal() {
    const modal = document.getElementById('modal');
    modal.style.display = 'none';
  }

  document.querySelector('.modal-close').addEventListener('click', closeModal);

  window.addEventListener('error', function(event) {
    handleError(event.error);
  });
});
