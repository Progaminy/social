document.addEventListener('DOMContentLoaded', () => {
  const token = localStorage.getItem('token');

  if (!token) {
    window.location.href = '/login';
  }

  document.getElementById('productForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('name', document.getElementById('name').value);
    formData.append('price', document.getElementById('price').value);
    formData.append('installmentAccepted', document.getElementById('installmentAccepted').checked);
    formData.append('location', document.getElementById('location').value);
    formData.append('contactNumber', document.getElementById('contactNumber').value);
    formData.append('category', document.getElementById('category').value);

    const images = document.getElementById('images').files;
    for (let i = 0; i < images.length; i++) {
      formData.append('images', images[i]);
    }

    try {
      const response = await fetch('/api/products/create', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      const data = await response.json();

      if (response.ok) {
        alert(data.message);
        window.location.href = '/main';
      } else {
        alert(data.message);
      }
    } catch (err) {
      alert('Erro ao criar produto. Por favor, tente novamente.');
    }
  });
});
